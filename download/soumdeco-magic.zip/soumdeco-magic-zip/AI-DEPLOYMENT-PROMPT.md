# AI DEPLOYMENT PROMPT — Replicate This Website

## YOUR ROLE
You are a senior full-stack developer. You will deploy this website for a new brand using the credentials I provide. Follow these steps EXACTLY. Do NOT skip any step. Do NOT modify any code unless I tell you to.

## WHAT I WILL PROVIDE (when you ask)
1. Google account credentials (for Google Sheets + Apps Script)
2. Cloudinary account (cloud name + upload preset)
3. Cloudflare account (API token + account ID)
4. GitHub account (token with repo + workflow scope)
5. Telegram bot token + chat ID (optional)
6. Brand name, tagline, logo, contact info, social links

## WHAT YOU MUST DO (in order)

### STEP 1: Google Sheet Setup
1. Create a new Google Sheet
2. Open Extensions → Apps Script
3. Paste `apps-script.gs` (replace YOUR_APPS_SCRIPT_URL_HERE if needed — it's self-referencing so no change needed)
4. Save → Deploy as web app (Execute as: Me, Access: Anyone)
5. Copy the deployment URL (ends with /exec)
6. This URL goes into: `src/lib/sheet.ts` (SHEET_BASE_URL) + `src/app/api/admin/route.ts` (APPS_SCRIPT_URL) + `.env` (NEXT_PUBLIC_SHEET_URL)

### STEP 2: Set Admin Token
1. In the Apps Script editor, add this at the top:
   ```javascript
   function setupToken() {
     var token = Browser.inputBox('Set Admin Token', 'Enter the admin token:', Browser.Buttons.OK_CANCEL);
     if (token && token !== 'cancel') {
       PropertiesService.getScriptProperties().setProperty('ADMIN_TOKEN', token.trim());
       Browser.msgBox('✅ Admin token saved.');
     }
   }
   ```
2. Select `setupToken` → Run → enter a random 30+ char string
3. Use this SAME token in: `src/app/api/admin/route.ts` (APPS_SCRIPT_ADMIN_TOKEN)
4. Delete the setupToken function after

### STEP 3: Cloudinary Setup
1. Sign up at cloudinary.com
2. Note your cloud name
3. Settings → Upload → Add unsigned upload preset
4. Put cloud name + preset in: `src/lib/drive-upload.ts` + `src/lib/client-sheet.ts` + `.env`

### STEP 4: Cloudflare Setup
1. Create a Pages project (connect to GitHub repo)
2. Create a KV namespace (note the ID)
3. Put KV ID in: `wrangler.toml` + `worker/wrangler.toml`
4. Create a Worker (paste `worker/data-sync.js`)
5. Set Worker secrets: `APPS_SCRIPT_URL` (your Apps Script URL), `ADMIN_SECRET` (your admin password)
6. Set Worker cron: `*/5 * * * *`
7. Put Worker URL in: `src/app/api/refresh/route.ts` + `src/app/api/catalog/route.ts` + `src/app/api/version/route.ts`

### STEP 5: Update Brand
1. Edit `src/lib/brand-config.ts` — replace ALL placeholder values
2. Replace `public/logo.svg/jpg/png` with brand logos
3. Edit `src/app/layout.tsx` — update metadata (title, description, URLs)
4. Edit `src/app/globals.css` — update color palette if needed

### STEP 6: Update Security Secrets
In `src/app/api/admin/route.ts`, change these 3 values:
- `ADMIN_PASSWORD` — your admin password
- `APPS_SCRIPT_ADMIN_TOKEN` — must match what you set in Step 2
- `SESSION_SIGNING_KEY` — any random 30+ char string

### STEP 7: Deploy
1. Push to GitHub
2. Set env vars in Cloudflare Pages dashboard
3. Deploy the Worker
4. Run `npm run build:cloudflare` locally to test
5. Test: visitor flow (browse, cart, order)
6. Test: admin flow (login, save product, delete product)

### STEP 8: GitHub Actions
The `.github/workflows/auto-sync-images.yml` runs daily at 2 AM UTC automatically.
No setup needed — it works once you push to GitHub.

## CRITICAL RULES (learned from past mistakes)
1. NEVER use `process.env` for non-NEXT_PUBLIC_ vars in Cloudflare edge runtime — hardcode them
2. NEVER split stockKey on comma — use semicolon only
3. NEVER treat empty stock as 0 — empty = INFINITE
4. NEVER retry orders (ORDER_RETRIES = 0) — prevents duplicates
5. ALWAYS use `nodejs_compat_v2` in wrangler.toml
6. ALWAYS test admin writes after deploying (login + save + delete)
7. ALWAYS verify the admin token is set in Apps Script before going live
8. ALWAYS sync upload/apps-script.gs with download/apps-script.gs
