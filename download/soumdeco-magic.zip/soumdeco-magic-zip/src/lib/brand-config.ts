// ============================================================
//  BRAND CONFIGURATION — REPLACE ALL VALUES WITH YOUR BRAND
// ============================================================
//  This file is imported by many components. Update every field
//  to match your brand before deploying.
// ============================================================

export const BRAND = {
  name: "YOUR_BRAND_NAME",
  nameLatin: "YourBrandName",
  tagline: "Your tagline here",
  adminPassword: "", // Kept empty — login via /api/admin (server-side only)
  logoPath: "/logo.jpg",

  contact: {
    instagram: "your_instagram",
    instagramUrl: "https://www.instagram.com/your_instagram/",
    facebook: "your_facebook",
    facebookUrl: "https://www.facebook.com/your_facebook",
    phone: "0000000000",
    phoneDisplay: "00 00 00 00",
    email: "your_email@gmail.com",
    address: "Your City, Your Country",
  },

  story: {
    title: "Your Story Title",
    paragraphs: [
      "Your brand story paragraph 1.",
      "Your brand story paragraph 2.",
    ],
  },

  storage: {
    catalog: "yourbrand_catalog_v1",
    cart: "yourbrand_cart_v1",
    stockCache: "yourbrand_stock_cache_v1",
    adminAuth: "yourbrand_admin_authed",
    failedOrders: "yourbrand_failed_orders",
  },

  cloudinary: {
    cloudName: "YOUR_CLOUDINARY_CLOUD_NAME",
    uploadPreset: "YOUR_CLOUDINARY_UPLOAD_PRESET",
  },
};
