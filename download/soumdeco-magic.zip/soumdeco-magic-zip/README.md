# Website Replication Package (Clean)

This zip contains the EXACT code of a production e-commerce website, with all brand info and credentials removed (replaced with YOUR_*_HERE placeholders).

## What's Included
- Full Next.js 15 + TypeScript + Tailwind 4 source code
- Google Apps Script backend (1,433 lines)
- Cloudflare Worker (541 lines)
- 10 API routes (including secure admin gateway)
- 25 React components
- 7 hooks, 18 lib modules
- GitHub Actions workflow (daily auto-sync)
- 9 test suites (286 checks)
- AI deployment prompt (step-by-step guide)

## What's NOT Included (you provide)
- Brand name, logo, contact info
- Google Sheet + Apps Script URL
- Cloudinary credentials
- Cloudflare account + KV namespace
- Telegram bot token (optional)
- Product images + data

## How to Use
1. Read `AI-DEPLOYMENT-PROMPT.md` — it has the complete step-by-step guide
2. Give the prompt + this zip to an AI assistant
3. Provide credentials when asked
4. The AI will deploy everything for you

## Test Suite
```bash
node scripts/test-comprehensive.js    # 212 checks
node scripts/test-stock-logic.js      # 7 checks
node scripts/test-variant-flow.js     # 4 checks
node scripts/test-server-extraction.js # 6 checks
node scripts/test-notes-extraction.js # 8 checks
node scripts/test-comma-bug-fix.js    # 2 checks
node scripts/test-stock-sync.js       # 11 checks
node scripts/test-cart-rapture.js     # 18 checks
node scripts/test-worker-wiring.js    # 18 checks
```

## Cost: $0/month (free tier)
- Cloudflare Pages: unlimited requests, 500 builds/month
- Cloudflare Workers: 100,000 requests/day
- Cloudflare KV: 100,000 reads/day, 1,000 writes/day
- Google Apps Script: 20,000 requests/day
- Cloudinary: 25 GB storage + 25 GB bandwidth/month
- GitHub Actions: 2,000 minutes/month

## Maximum Capacity
- Browsing: ~30,000-50,000 visitors/day
- Orders: ~2,000-3,500 orders/day (Apps Script bottleneck)
- Concurrent: ~1,000 visitors browsing simultaneously
