"use client";

import { useCallback, useEffect, useRef, useState } from "react";
import {
  Product,
  Variation,
  ProductVariant,
  CATALOG_STORAGE_KEY,
  saveCatalog,
  saveCatalogAsync,
  loadCatalog,
  loadCatalogAsync,
  generateId,
  parseVariations,
  parseHighlights,
  normalizeTiers,
  normalizeVariants,
  SEED_PRODUCTS,
} from "@/lib/products";
import {
  clientListProducts,
  clientUpsertProduct,
  clientDeleteProduct,
  clientResetProducts,
  clientUploadImages,
} from "@/lib/client-sheet";
import { getLocalPathSync, loadImageManifest } from "@/lib/image-manifest";
import {
  joinImageStrings,
  joinVariations,
  joinVariants,
  joinHighlights,
} from "@/lib/products";
import type { SheetProduct } from "@/lib/sheet";

// Polling intervals — optimized for near-instant updates.
// Visible tab: 1 minute (visitors see admin edits within 1 min max)
// Hidden tab: 10 minutes (less frequent when not looking)
//
// Quota math at 50K visitors/day (worst case):
//   - 1 fetch per page load (initial) = 50K Worker requests
//   - Polling: assume 10% stay 5 min = 5K × 5 polls = 25K
//   - Total: 75K Worker requests/day (under 100K limit) ✅
//   - KV reads: 75K/day (under 100K limit) ✅
const POLL_MS = 60_000; // 1 minute when tab is visible
const HIDDEN_POLL_MS = 600_000; // 10 minutes when tab is hidden

export function useCatalog() {
  // Initialize empty on both server and client (hydration-safe)
  const [products, setProducts] = useState<Product[]>([]);
  const [hydrated, setHydrated] = useState(false);
  const [loading, setLoading] = useState(true);
  const [syncing, setSyncing] = useState(false);
  const pollRef = useRef<ReturnType<typeof setInterval> | null>(null);
  const isVisibleRef = useRef(true);
  // Always-current snapshot of products — used by callbacks that need
  // the latest products without re-creating the callback (e.g. addBlankProduct).
  const productsRef = useRef<Product[]>([]);
  useEffect(() => {
    productsRef.current = products;
  }, [products]);

  // CRITICAL: Tracks the timestamp of the latest admin operation.
  // Background refresh results are DISCARDED if they're older than this.
  // This prevents stale Worker KV data from reverting a newer optimistic update.
  //
  // PERSISTED TO localStorage: Survives page refresh.
  // THE FIX: Grace period extended to 10 MINUTES (was 5 min).
  // Why: After 5 min, the admin's own background polling (every 2 min)
  // would fire refresh() → fetchCatalog(). But fetchCatalog has a 10s
  // frontend cache that returns STALE data (from before the edit). That
  // stale data would overwrite the admin's optimistic update → REVERT.
  // 10 minutes gives plenty of time for: admin to finish editing,
  // Worker KV to fully propagate, and the 10s frontend cache to expire.
  const ADMIN_OP_TS_KEY = "soumdeco_last_admin_op_ts";
  const lastAdminOpTsRef = useRef<number>(0);

  // On mount, restore the timestamp from localStorage
  useEffect(() => {
    try {
      const saved = window.localStorage.getItem(ADMIN_OP_TS_KEY);
      if (saved) {
        const ts = parseInt(saved, 10);
        if (!isNaN(ts) && ts > 0) {
          lastAdminOpTsRef.current = ts;
        }
      }
    } catch {}
  }, []);

  // Helper to update the timestamp (persists to localStorage)
  const updateLastAdminOpTs = useCallback((ts: number) => {
    lastAdminOpTsRef.current = ts;
    try {
      window.localStorage.setItem(ADMIN_OP_TS_KEY, String(ts));
    } catch {}
  }, []);

  // CRITICAL: Tracks the number of pending admin operations.
  // Only trigger the background refresh when ALL pending ops have completed
  // their POSTs. This prevents:
  // 1. Quota waste (10 rapid deletes = 1 refresh, not 10)
  // 2. Race condition (refresh #1 fetches from Apps Script before op B's POST
  //    completes → returns stale data → reverts op B's optimistic update)
  const pendingOpsRef = useRef<number>(0);

  // ---- ADAPTIVE FETCH (Worker-first, never crashes) ----
  // Chain: Worker (5-min fresh) → static JSON (max 24h) → cache → seed
  // Worker is OPTIONAL — if NEXT_PUBLIC_WORKER_URL is not set, it's skipped
  // and we use static JSON (current behavior). This means deploying the
  // worker is an OPT-IN upgrade — site works fine without it.
  //
  // VISITOR FLOW:
  //   1. Try Worker (?action=catalog) — 5s timeout, returns products+stock
  //   2. If Worker fails OR not configured → try static /data/products.json
  //   3. If static also fails → use localStorage cache
  //   4. If cache empty → use SEED_PRODUCTS (built-in fallback)
  //
  // CRITICAL: No per-visitor Apps Script calls. This ensures the site
  // can handle 50K+ visits/day without hitting Apps Script's 20K/day limit.
  // The Worker pulls from Apps Script via cron (288 calls/day = 1.4% quota).

  const refresh = useCallback(async () => {
    try {
      // ════════════════════════════════════════════════════════════
      //  ADMIN MODE PROTECTION — BULLETPROOF REVERT FIX
      // ════════════════════════════════════════════════════════════
      //  When the admin panel is open (URL hash = #admin), SKIP ALL
      //  background fetching. The admin's optimistic updates are the
      //  ONLY source of truth. Any background fetch (Worker KV, static
      //  JSON, localStorage, IndexedDB) could return STALE data and
      //  REVERT the admin's changes.
      //
      //  This is the bulletproof fix for: "admin edits product name,
      //  it reverts to original after a short time."
      //
      //  Root cause was: background polling → fetch from Worker KV →
      //  KV might be stale (propagation delay, rate-limited /refresh) →
      //  setProducts(staleData) → admin sees old name come back.
      //
      //  Fix: While in admin mode, NEVER fetch. Admin's optimistic
      //  update stays until admin exits to home page. Then normal
      //  polling resumes (KV is fresh by then — cron + /refresh have run).
      // ════════════════════════════════════════════════════════════
      if (typeof window !== "undefined") {
        const hash = window.location.hash.toLowerCase();
        if (hash === "#admin" || hash.startsWith("#admin/")) {
          // Admin mode — DON'T fetch anything. Keep optimistic updates.
          setLoading(false);
          return;
        }
      }

      // 0. INSTANTLY show cached data (for returning visitors — 0ms)
      const instantCached = loadCatalog();
      if (instantCached.length > 0) {
        let quick = instantCached.map(optimizeCloudinaryUrls).map(fixCategoryTypos);
        quick.sort((a, b) => (a.sortOrder ?? 999) - (b.sortOrder ?? 999));
        setProducts(quick);
        setLoading(false);
      }

      // ADMIN PROTECTION: If admin did an operation recently (within 10 minutes),
      // SKIP fetching fresh data. The admin's optimistic update is correct, and
      // fetching from Worker KV might return stale data (KV propagation delay,
      // rate-limited /refresh, OR frontend cache returning pre-edit data).
      // 10 minutes is bulletproof: covers KV propagation (1 min) + frontend
      // cache expiry (10s) + any background polling that might fire.
      const ADMIN_GRACE_PERIOD_MS = 600_000; // 10 minutes (was 5 min)
      const timeSinceLastAdminOp = Date.now() - lastAdminOpTsRef.current;
      const withinAdminGracePeriod =
        lastAdminOpTsRef.current > 0 &&
        timeSinceLastAdminOp < ADMIN_GRACE_PERIOD_MS;

      if (withinAdminGracePeriod) {
        // Admin recently edited — DON'T fetch fresh data (would revert).
        // Keep the optimistic update. Loading is already false.
        setLoading(false);
        return;
      }

      // 1. Fetch from Worker (if deployed) or static JSON (fallback)
      // Track the server timestamp so we can detect stale data (older than admin op)
      let fetched: SheetProduct[] = [];
      let catalogTs = 0;
      try {
        const { fetchCatalog } = await import("@/lib/worker-client");
        const result = await fetchCatalog();
        if (result.products.length > 0) {
          fetched = result.products;
          catalogTs = result.ts || 0;
        }
      } catch {
        // Fetch failed — will fall through to cache/seed
      }

      // RE-CHECK after async fetch: admin might have done an op while we were fetching.
      const timeSinceLastAdminOpAfterFetch = Date.now() - lastAdminOpTsRef.current;
      const adminDidOpDuringFetch =
        lastAdminOpTsRef.current > 0 &&
        timeSinceLastAdminOpAfterFetch < ADMIN_GRACE_PERIOD_MS;
      if (adminDidOpDuringFetch) {
        setLoading(false);
        return; // discard — admin's optimistic update is correct
      }

      // DATA FRESHNESS CHECK: If the fetched data is OLDER than the last
      // admin op, discard it. This catches the case where the frontend
      // cache (10s TTL) returns stale data from before the admin edit.
      // We compare the catalog's `ts` (server timestamp) against the
      // admin op timestamp. If server data is older, it's stale.
      // (This is the bulletproof fix for the revert bug.)
      if (lastAdminOpTsRef.current > 0 && catalogTs > 0) {
        if (catalogTs < lastAdminOpTsRef.current) {
          // Server data is older than the admin op → stale → discard
          setLoading(false);
          return;
        }
      }

      if (fetched.length > 0) {
        const seen = new Set<string>();
        const unique: SheetProduct[] = [];
        for (const p of fetched) {
          const id = String(p.id || "").trim();
          if (!id || seen.has(id)) continue;
          seen.add(id);
          unique.push(p);
        }

        let next: Product[] = unique.map(normalizeProduct);
        next = next.map(fixCategoryTypos);
        next = next.map(optimizeCloudinaryUrls);
        next.sort((a, b) => (a.sortOrder ?? 999) - (b.sortOrder ?? 999));

        saveCatalog(next);
        saveCatalogAsync(next).catch(() => {});
        setProducts(next);
        setLoading(false);
        return;
      }

      // 2. Static JSON failed — use cache, then seed
      const cached = await loadCatalogAsync();
      if (cached.length > 0) {
        let sorted = cached.map(optimizeCloudinaryUrls).map(fixCategoryTypos);
        sorted.sort((a, b) => (a.sortOrder ?? 999) - (b.sortOrder ?? 999));
        setProducts(sorted);
        setLoading(false);
        return;
      }
      const seeded = [...SEED_PRODUCTS].sort(
        (a, b) => (a.sortOrder ?? 999) - (b.sortOrder ?? 999),
      );
      saveCatalog(seeded);
      setProducts(seeded);
      setLoading(false);
    } catch {
      const cachedSync = loadCatalog();
      if (cachedSync.length > 0) {
        const sorted = [...cachedSync].map(optimizeCloudinaryUrls).map(fixCategoryTypos);
        sorted.sort((a, b) => (a.sortOrder ?? 999) - (b.sortOrder ?? 999));
        setProducts(sorted);
      } else {
        const seeded = [...SEED_PRODUCTS].sort(
          (a, b) => (a.sortOrder ?? 999) - (b.sortOrder ?? 999),
        );
        saveCatalog(seeded);
        setProducts(seeded);
      }
      setLoading(false);
    }
  }, []);

  // Schedule the next poll based on current visibility
  const scheduleNext = useCallback(() => {
    if (pollRef.current) clearInterval(pollRef.current);
    const delay = isVisibleRef.current ? POLL_MS : HIDDEN_POLL_MS;
    pollRef.current = setInterval(refresh, delay);
  }, [refresh]);

  // Initial load + polling
  useEffect(() => {
    // WIFI FIX: ALWAYS show data instantly — never block on network fetch.
    // If no cached data, use SEED_PRODUCTS immediately. This prevents
    // "stuck at loading" on slow/blocked WiFi networks.
    let cached: Product[] = loadCatalog();
    // If cache is empty for ANY reason (first visit, corrupted, cleared),
    // ALWAYS fall back to SEED_PRODUCTS — never show infinite loading.
    if (cached.length === 0) {
      cached = SEED_PRODUCTS;
      saveCatalog(SEED_PRODUCTS);
    }
    // Apply URL rewriting to cached products too — the cache may have
    // old Cloudinary URLs from before the local-image migration.
    cached = cached.map(optimizeCloudinaryUrls);
    cached = cached.map(fixCategoryTypos);
    // Sort by sortOrder (lower first)
    const sorted = [...cached];
    sorted.sort((a, b) => (a.sortOrder ?? 999) - (b.sortOrder ?? 999));
    setProducts(sorted);
    setHydrated(true);
    // CRITICAL: Set loading=false IMMEDIATELY. We ALWAYS have data (cache or seed).
    // Users NEVER see "stuck at loading" — even on slow/blocked WiFi.
    setLoading(false);
    // If we have cached data, delay the refresh slightly (300ms) so the
    // page can paint first. This makes navigation feel instant.
    // If no cached data, fetch immediately (we need it to show anything).
    if (cached.length > 0) {
      setTimeout(() => refresh(), 300);
    } else {
      refresh();
    }
    scheduleNext();

    // Also try loading from IndexedDB (handles large catalogs that overflow
    // localStorage — the sync loadCatalog() above may have missed them)
    // ONLY use IndexedDB data if we DON'T have fresher data already loaded.
    // The refresh() call above fetches from the sheet (source of truth) —
    // if it completes before this IndexedDB check, we skip the stale data.
    loadCatalogAsync().then((asyncCached) => {
      // Only use IndexedDB data if:
      // 1. It has more products than the sync cache (localStorage overflow case)
      // 2. The sheet refresh hasn't already loaded fresher data
      // We check productsRef.current (latest state) instead of the stale `cached`
      const currentCount = productsRef.current.length;
      if (asyncCached.length > currentCount && currentCount <= cached.length) {
        let sorted = asyncCached.map(optimizeCloudinaryUrls).map(fixCategoryTypos);
        sorted.sort((a, b) => (a.sortOrder ?? 999) - (b.sortOrder ?? 999));
        setProducts(sorted);
      }
    }).catch(() => {});

    // Load the image manifest, then RE-APPLY optimizeCloudinaryUrls.
    // On initial render, the manifest isn't loaded yet, so URLs stay as
    // Cloudinary (which works but throttles under load). Once the manifest
    // loads (~200ms later), we rewrite to local Paths paths (unlimited bandwidth).
    loadImageManifest()
      .then(() => {
        const current = productsRef.current;
        if (current.length > 0) {
          const rewritten = current.map(optimizeCloudinaryUrls);
          setProducts(rewritten);
        }
      })
      .catch(() => {});

    // Retry any failed orders from the retry queue (background, non-blocking).
    // This runs on every page visit — if the previous order failed to submit,
    // it gets retried here silently.
    import("@/lib/failed-orders")
      .then(({ retryFailedOrders }) => retryFailedOrders())
      .catch(() => {});

    // Pause/slow polling when tab hidden, refresh immediately when visible again
    const onVisibility = () => {
      const wasHidden = !isVisibleRef.current;
      isVisibleRef.current = !document.hidden;
      if (!document.hidden && wasHidden) refresh();
      scheduleNext();
    };
    document.addEventListener("visibilitychange", onVisibility);

    return () => {
      if (pollRef.current) clearInterval(pollRef.current);
      document.removeEventListener("visibilitychange", onVisibility);
    };
  }, [refresh, scheduleNext]);

  // ---- SHARED HELPER: Sync Worker KV after admin op ----
  // Used by upsertProduct, deleteProduct, moveProduct, resetCatalog.
  //
  // CRITICAL: This function ONLY triggers the Worker /refresh endpoint
  // to update KV for OTHER visitors. It does NOT overwrite the admin's
  // React state with fresh KV data, because:
  // 1. The admin's optimistic update is ALREADY correct (instant)
  // 2. Worker KV might be stale (rate-limited refresh, propagation delay)
  // 3. Applying stale KV data would REVERT the optimistic update
  //    (admin sees old description come back after 2-5s) ← THE BUG
  //
  // The admin's browser keeps the optimistic update. Other visitors get
  // fresh data from Worker KV within 5-10 seconds (after /refresh completes).
  //
  // pendingOpsRef: Only trigger ONE /refresh when all pending ops complete.
  // This saves quota (10 rapid deletes = 1 refresh, not 10).
  const applyFreshCatalogAfterOp = useCallback(
    async (opTs: number) => {
      // Decrement pending ops counter
      pendingOpsRef.current = Math.max(0, pendingOpsRef.current - 1);

      // If there are still pending ops, DON'T refresh yet.
      // The LAST op (when counter reaches 0) will trigger the refresh.
      if (pendingOpsRef.current > 0) {
        return;
      }

      // If a newer op started, abort (it will trigger its own refresh).
      if (opTs < lastAdminOpTsRef.current) {
        return;
      }

      // Trigger Worker /refresh in the BACKGROUND.
      // This updates Worker KV so OTHER visitors see the changes within 5-10s.
      // We DON'T apply the result to the admin's state — the optimistic update is correct.
      try {
        const { triggerWorkerRefreshOnly } = await import("@/lib/worker-client");
        await triggerWorkerRefreshOnly();
        // intentionally NOT calling setProducts() — keep the optimistic update
      } catch {
        // Silent — Worker cron will eventually sync (5 min)
      }
    },
    [],
  );

  // ---- UPSERT (admin) ----
  // Uploads images to Cloudinary (client-side unsigned upload), then
  // POSTs the product directly to Google Apps Script.
  //
  // BULLETPROOF + FAST:
  //  - Images are uploaded on SELECT (in admin-panel handleFiles), so by
  //    the time Save is clicked, photos are already Cloudinary URLs.
  //  - clientUploadImages skips URLs (not data: URLs), so it's instant.
  //  - After a successful POST, we DON'T await a full refresh — the
  //    optimistic update already shows the change. A background refresh
  //    is scheduled (non-blocking) to sync any sheet-side changes.
  //  - On failure, rolls back the optimistic update + throws an error
  //    so the admin panel can show a failure toast.
  const upsertProduct = useCallback(
    async (product: Product) => {
      // Save the previous state for rollback
      const previousProducts = productsRef.current;
      // Stamp this op so we can discard stale refresh results later
      const opTs = Date.now();
      updateLastAdminOpTs(opTs);
      pendingOpsRef.current += 1; // track pending ops

      // Optimistic local update (INSTANT — UI shows the change immediately)
      const idx = previousProducts.findIndex((p) => p.id === product.id);
      let optimisticNext: Product[];
      if (idx >= 0) {
        optimisticNext = [...previousProducts];
        optimisticNext[idx] = product;
      } else {
        optimisticNext = [product, ...previousProducts];
      }
      optimisticNext.sort((a, b) => (a.sortOrder ?? 999) - (b.sortOrder ?? 999));
      setProducts(optimisticNext);
      saveCatalog(optimisticNext);

      // Sync to Apps Script
      setSyncing(true);
      try {
        // 1. Upload any base64 images to Cloudinary.
        //    Since images are now uploaded on SELECT (in handleFiles),
        //    this is typically a no-op — the photos are already URLs.
        //    This call only runs for the rare case of leftover base64 images.
        const imagesToUpload = product.images || (product.image ? [product.image] : []);
        const uploadedUrls = await clientUploadImages(imagesToUpload, product.id);
        const coverImage = uploadedUrls[0] || product.image || "";

        // 2. Build the SheetProduct payload
        const sheetProduct: SheetProduct = {
          id: product.id,
          name: product.name,
          description: product.description,
          category: product.category,
          price: product.price,
          image: coverImage,
          images: joinImageStrings(uploadedUrls),
          featured: product.featured,
          isSpecialOffer: product.isSpecialOffer ?? false,
          variations: joinVariations(product.variations),
          variants: joinVariants(product.variants),
          stock: product.stock ?? null,
          highlights: joinHighlights(product.highlights),
          sortOrder: product.sortOrder ?? 999,
          badge: product.badge || "",
          oldPrice: product.oldPrice ?? null,
          quantityTiers: Array.isArray(product.quantityTiers)
            ? (product.quantityTiers as any[])
                .filter((t) => t && typeof t.qty === "number")
                .map((t) => `${t.qty}:${t.freeShipping || "none"}:${t.discountAmount || 0}:${t.mode || "exact"}`)
                .join(",")
            : String((product as any).quantityTiers ?? ""),
        };

        // 3. POST to Apps Script (the ONLY slow step — 1-3s)
        const ok = await clientUpsertProduct(sheetProduct);
        if (!ok) {
          // ROLLBACK — the product didn't save to the sheet.
          setProducts(previousProducts);
          saveCatalog(previousProducts);
          throw new Error("Apps Script POST failed — product not saved to sheet");
        }
        // 4. After successful save, refresh Worker KV + fetch fresh catalog.
        //    applyFreshCatalogAfterOp decrements pendingOpsRef and triggers
        //    refresh only when ALL pending ops are done (+ 2s delay).
        setTimeout(() => { applyFreshCatalogAfterOp(opTs); }, 100);
      } catch (e) {
        // If error happened AFTER the optimistic update, rollback
        console.error("[upsertProduct] error:", e);
        setProducts(previousProducts);
        saveCatalog(previousProducts);
        // Decrement pendingOpsRef since this op is done (failed)
        pendingOpsRef.current = Math.max(0, pendingOpsRef.current - 1);
        throw e; // re-throw so admin panel can show error toast
      } finally {
        setSyncing(false);
      }
    },
    [applyFreshCatalogAfterOp, updateLastAdminOpTs],
  );

  // ---- DELETE (admin) ----
  // BULLETPROOF: On failure, restores the deleted product so the UI
  // stays consistent with the sheet. Throws on failure.
  //
  // CRITICAL: After deletion, we MUST refresh the Worker KV cache,
  // otherwise the next catalog refresh will pull stale KV data
  // (which still has the deleted product) and revert the optimistic
  // update — making the product "come back".
  const deleteProduct = useCallback(
    async (id: string) => {
      const previousProducts = productsRef.current;
      const deletedProduct = previousProducts.find((p) => p.id === id);
      // Stamp this op so we can discard stale refresh results later
      const opTs = Date.now();
      updateLastAdminOpTs(opTs);
      pendingOpsRef.current += 1; // track pending ops

      // Optimistic: remove from state + localStorage
      const next = previousProducts.filter((p) => p.id !== id);
      setProducts(next);
      saveCatalog(next);

      setSyncing(true);
      try {
        const ok = await clientDeleteProduct(id);
        if (!ok) {
          // ROLLBACK — restore the deleted product
          if (deletedProduct) {
            const restored = [...previousProducts];
            restored.sort((a, b) => (a.sortOrder ?? 999) - (b.sortOrder ?? 999));
            setProducts(restored);
            saveCatalog(restored);
          }
          throw new Error("Apps Script delete failed — product not removed from sheet");
        }
        // After successful deletion, refresh Worker KV + fetch fresh catalog.
        // applyFreshCatalogAfterOp decrements pendingOpsRef and triggers
        // refresh only when ALL pending ops are done (+ 2s delay).
        setTimeout(() => { applyFreshCatalogAfterOp(opTs); }, 100);
      } catch (e) {
        console.error("[deleteProduct] error:", e);
        // Rollback if not already done
        if (deletedProduct) {
          const restored = [...previousProducts];
          restored.sort((a, b) => (a.sortOrder ?? 999) - (b.sortOrder ?? 999));
          setProducts(restored);
          saveCatalog(restored);
        }
        // Decrement pendingOpsRef since this op is done (failed)
        pendingOpsRef.current = Math.max(0, pendingOpsRef.current - 1);
        throw e;
      } finally {
        setSyncing(false);
      }
    },
    [applyFreshCatalogAfterOp, updateLastAdminOpTs],
  );

  // ---- ADD BLANK (admin) ----
  const addBlankProduct = useCallback(() => {
    // New products appear at the bottom of the list by default.
    const maxSort = productsRef.current.reduce(
      (max, p) => Math.max(max, p.sortOrder ?? 0),
      0,
    );
    const newProduct: Product = {
      id: generateId("nouveau"),
      name: "",
      description: "",
      category: "",
      price: null,
      oldPrice: null,
      image: "",
      images: [],
      featured: false,
      inStock: true,
      isSpecialOffer: false,
      variations: [],
      variants: [],
      stock: null,
      highlights: [],
      sortOrder: maxSort + 1,
      badge: "",
      quantityTiers: [],
    };
    return newProduct;
  }, []);

  // ---- REORDER (admin) ----
  // Move a product up (toward the front of the list) or down (toward the back).
  // Swaps its sortOrder with the adjacent product, persists to localStorage,
  // re-sorts the visible list immediately, and syncs both products to the sheet.
  //
  // CRITICAL: After swapping, refresh Worker KV — otherwise stale sort order
  // in KV will revert the swap on the next admin op's refresh.
  const moveProduct = useCallback(
    (id: string, direction: "up" | "down") => {
      // Stamp this op so we can discard stale refresh results later
      const opTs = Date.now();
      updateLastAdminOpTs(opTs);
      pendingOpsRef.current += 1; // track pending ops

      let toSync: Product[] = [];
      setProducts((prev) => {
        if (prev.length < 2) return prev;
        // Ensure sorted by sortOrder before swap
        const sorted = [...prev].sort(
          (a, b) => (a.sortOrder ?? 999) - (b.sortOrder ?? 999),
        );
        const idx = sorted.findIndex((p) => p.id === id);
        if (idx < 0) return prev;
        const swapWith = direction === "up" ? idx - 1 : idx + 1;
        if (swapWith < 0 || swapWith >= sorted.length) return prev;
        // Swap sortOrder values — create NEW objects (don't mutate)
        const aOrder = sorted[idx].sortOrder ?? 999;
        const bOrder = sorted[swapWith].sortOrder ?? 999;
        const newA = { ...sorted[idx], sortOrder: bOrder };
        const newB = { ...sorted[swapWith], sortOrder: aOrder };
        sorted[idx] = newA;
        sorted[swapWith] = newB;
        // Re-sort
        sorted.sort((x, y) => (x.sortOrder ?? 999) - (y.sortOrder ?? 999));
        saveCatalog(sorted);
        // Collect the 2 products to sync to the sheet
        toSync = [newA, newB];
        return sorted;
      });
      // Sync both swapped products directly to Apps Script (fire and forget)
      if (toSync.length === 2) {
        let successCount = 0;
        let failureCount = 0;
        const checkComplete = () => {
          // When both swaps are done (success or failure), call applyFreshCatalogAfterOp
          // which decrements pendingOpsRef and triggers refresh when all ops are done
          if (successCount + failureCount === 2) {
            applyFreshCatalogAfterOp(opTs);
          }
        };
        for (const p of toSync) {
          const sheetProduct: SheetProduct = {
            id: p.id,
            name: p.name,
            description: p.description,
            category: p.category,
            price: p.price,
            image: p.image,
            images: joinImageStrings(p.images || []),
            featured: p.featured,
            isSpecialOffer: p.isSpecialOffer ?? false,
            variations: joinVariations(p.variations),
            variants: joinVariants(p.variants),
            stock: p.stock ?? null,
            highlights: joinHighlights(p.highlights),
            sortOrder: p.sortOrder ?? 999,
            badge: p.badge || "",
            oldPrice: p.oldPrice ?? null,
            quantityTiers: Array.isArray(p.quantityTiers)
              ? (p.quantityTiers as any[])
                  .filter((t) => t && typeof t.qty === "number")
                  .map((t) => `${t.qty}:${t.freeShipping || "none"}:${t.discountAmount || 0}:${t.mode || "exact"}`)
                  .join(",")
              : "",
          };
          clientUpsertProduct(sheetProduct)
            .then((ok) => {
              if (ok) {
                successCount++;
              } else {
                failureCount++;
                console.error(`[moveProduct] Failed to sync ${p.id} to sheet`);
              }
              checkComplete();
            })
            .catch((err) => {
              failureCount++;
              console.error(`[moveProduct] Error syncing ${p.id}:`, err);
              checkComplete();
            });
        }
      } else {
        // No products to sync — still decrement pendingOpsRef
        applyFreshCatalogAfterOp(opTs);
      }
    },
    [applyFreshCatalogAfterOp, updateLastAdminOpTs],
  );

  // ---- RESET (admin) ----
  // BULLETPROOF: On failure, restores the previous products so the UI
  // stays consistent with the sheet. Throws on failure.
  const resetCatalog = useCallback(async () => {
    const previousProducts = productsRef.current;
    // Stamp this op so we can discard stale refresh results later
    const opTs = Date.now();
    updateLastAdminOpTs(opTs);
    pendingOpsRef.current += 1; // track pending ops

    setSyncing(true);
    try {
      // Reset localStorage to SEED_PRODUCTS FIRST (so the UI updates immediately)
      saveCatalog(SEED_PRODUCTS);
      const sorted = [...SEED_PRODUCTS].sort(
        (a, b) => (a.sortOrder ?? 999) - (b.sortOrder ?? 999),
      );
      setProducts(sorted);
      // Then reset the sheet directly via Apps Script
      const ok = await clientResetProducts();
      if (!ok) {
        // ROLLBACK — restore previous products
        const restored = [...previousProducts].sort(
          (a, b) => (a.sortOrder ?? 999) - (b.sortOrder ?? 999),
        );
        setProducts(restored);
        saveCatalog(restored);
        throw new Error("Apps Script reset failed — sheet not cleared");
      }
      // After reset, refresh Worker KV + fetch fresh catalog.
      // applyFreshCatalogAfterOp decrements pendingOpsRef and triggers
      // refresh only when ALL pending ops are done (+ 2s delay).
      setTimeout(() => { applyFreshCatalogAfterOp(opTs); }, 100);
    } catch (e) {
      // Decrement pendingOpsRef since this op is done (failed)
      pendingOpsRef.current = Math.max(0, pendingOpsRef.current - 1);
      throw e;
    } finally {
      setSyncing(false);
    }
  }, [applyFreshCatalogAfterOp, updateLastAdminOpTs]);

  return {
    products,
    hydrated,
    loading,
    syncing,
    upsertProduct,
    deleteProduct,
    addBlankProduct,
    moveProduct,
    resetCatalog,
    refresh,
  };
}

// ---------- internal ----------

/**
 * Fix common category name typos that exist in the Google Sheet data.
 * - "Meubes" → "Meubles" (missing 'l')
 * - Trim whitespace
 * - Normalize case for known categories
 */
function fixCategoryTypos(p: Product): Product {
  let cat = (p.category || "").trim();
  if (cat === "Meubes") cat = "Meubles";
  if (cat !== p.category) {
    return { ...p, category: cat };
  }
  return p;
}

/**
 * Rewrite Cloudinary URLs to LOCAL Cloudflare Pages paths.
 *
 * WHY: Cloudinary throttles when 80+ images load simultaneously (causing
 * the "images don't show" bug). Cloudflare Pages has unlimited bandwidth
 * AND unlimited requests — zero throttling.
 *
 * HOW: The image manifest (/public/image-manifest.json) lists all local
 * files. We check if a Cloudinary URL's filename is in the manifest.
 * If yes → rewrite to /images/products/{filename} (served from Pages).
 * If no  → keep Cloudinary URL (image not yet synced, Cloudinary fallback).
 *
 * NEW uploads: Go to Cloudinary first (instant display). After the daily
 * sync runs (GitHub Actions), they're downloaded to /public/images/products/
 * and the manifest is rebuilt. On next deploy, they're served from Pages.
 *
 * This is the BULLETPROOF strategy:
 *  - All existing images: served from Pages (unlimited, no throttling)
 *  - New uploads: served from Cloudinary (instant, until next sync)
 *  - Cloudinary bandwidth: near zero (only new uploads use it)
 *  - Pages bandwidth: unlimited (handles 800K visits/month)
 */
function optimizeCloudinaryUrls(p: Product): Product {
  const CLOUDINARY_RE = /^https?:\/\/res\.cloudinary\.com\/[^/]+\/image\/upload\/(?:[^/]+\/)?(?:v\d+\/)?(.+)$/;

  const rewriteOne = (url: string): string => {
    if (!url || typeof url !== "string") return url;
    if (!url.includes("res.cloudinary.com")) return url;
    const match = url.match(CLOUDINARY_RE);
    if (!match) return url;

    // Check if this image is in the local manifest (hot tier)
    const filename = match[1];
    const localPath = getLocalPathSync(url);
    if (localPath) {
      return localPath; // serve from Cloudflare Pages (unlimited bandwidth)
    }
    return url; // serve from Cloudinary (not yet synced)
  };

  const newImage = rewriteOne(p.image);
  let newImages: string[] | undefined = p.images;
  if (Array.isArray(p.images)) {
    newImages = p.images.map(rewriteOne);
  }

  if (newImage !== p.image || newImages !== p.images) {
    return { ...p, image: newImage, images: newImages };
  }
  return p;
}

function normalizeProduct(p: any): Product {
  const toStr = (v: any): string => {
    if (v == null) return "";
    if (typeof v === "string") return v;
    return String(v);
  };
  const image = toStr(p.image);
  let images: string[] = [];
  if (Array.isArray(p.images)) {
    images = p.images.map(toStr).filter((s) => s.trim() !== "");
  } else if (typeof p.images === "string" && p.images.trim() !== "") {
    const s = p.images.trim();
    if (s.includes("~~~")) {
      images = s.split("~~~").map((x) => x.trim()).filter((x) => x !== "");
    } else if (s.includes("|||")) {
      images = s.split("|||").map((x) => x.trim()).filter((x) => x !== "");
    } else if (s.includes("|")) {
      images = s.split("|").map((x) => x.trim()).filter((x) => x !== "");
    } else if (s.includes("data:")) {
      images = s.split(/,(?=data:)/).map((x) => x.trim()).filter((x) => x !== "");
    } else {
      images = s.split(",").map((x) => x.trim()).filter((x) => x !== "");
    }
  }
  images = Array.from(new Set(images));
  if (image && images[0] !== image) {
    images = [image, ...images.filter((i) => i !== image)];
  }
  return {
    id: String(p.id ?? ""),
    name: toStr(p.name),
    description: toStr(p.description ?? ""),
    category: toStr(p.category),
    price:
      p.price === null ||
      p.price === undefined ||
      p.price === "" ||
      (typeof p.price === "object" && p.price !== null)
        ? null
        : Number(p.price),
    oldPrice:
      p.oldPrice === null ||
      p.oldPrice === undefined ||
      p.oldPrice === "" ||
      (typeof p.oldPrice === "object" && p.oldPrice !== null)
        ? null
        : Number(p.oldPrice),
    image,
    images,
    variations: Array.isArray(p.variations)
      ? (p.variations as Variation[]).filter(
          (v) => v && v.name && Array.isArray(v.options) && v.options.length > 0,
        )
      : parseVariations(typeof p.variations === "string" ? p.variations : ""),
    variants: normalizeVariants(p.variants) as ProductVariant[],
    stock:
      p.stock === null ||
      p.stock === undefined ||
      p.stock === "" ||
      (typeof p.stock === "object" && p.stock !== null)
        ? null
        : Number(p.stock),
    highlights: Array.isArray(p.highlights)
      ? (p.highlights as string[]).map((h) => String(h)).filter((h) => h.trim() !== "")
      : parseHighlights(typeof p.highlights === "string" ? p.highlights : ""),
    sortOrder:
      p.sortOrder === null || p.sortOrder === undefined
        ? 999
        : Number(p.sortOrder),
    badge:
      p.badge === null || p.badge === undefined ? "" : String(p.badge),
    quantityTiers: normalizeTiers(p.quantityTiers),
    featured: (p.featured === true ||
               p.featured === 1 ||
               p.featured === "1" ||
               (typeof p.featured === "string" &&
                p.featured.toLowerCase() === "true")),
    isSpecialOffer: (p.isSpecialOffer === true ||
                     p.isSpecialOffer === 1 ||
                     p.isSpecialOffer === "1" ||
                     (typeof p.isSpecialOffer === "string" &&
                      p.isSpecialOffer.toLowerCase() === "true")),
    inStock: p.inStock !== false,
  };
}
