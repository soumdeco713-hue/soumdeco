"use client";

import { useCallback, useEffect, useState } from "react";
import { CART_STORAGE_KEY } from "@/lib/products";

export type CartItem = {
  productId: string;
  name: string;
  price: number | null;
  image: string;
  quantity: number;
  /** Variant info (e.g. "أحمر / كبير") — if set, items with same productId
   *  but different variantKey are treated as separate line items. */
  variantKey?: string;
};

const MAX_QUANTITY = 99;
const MIN_QUANTITY = 1;

/** Sanitize a single cart item (defensive — never throws). */
function sanitizeItem(item: any): CartItem | null {
  if (!item || typeof item !== "object") return null;
  if (typeof item.productId !== "string" || item.productId.trim() === "") return null;
  if (typeof item.name !== "string") return null;
  const qty = typeof item.quantity === "number" && !isNaN(item.quantity) ? item.quantity : 0;
  if (qty <= 0 || qty >= 1000) return null;
  return {
    productId: String(item.productId),
    name: String(item.name),
    price:
      typeof item.price === "number" && !isNaN(item.price) ? item.price : null,
    image: typeof item.image === "string" ? item.image : "",
    quantity: Math.min(MAX_QUANTITY, Math.max(MIN_QUANTITY, Math.floor(qty))),
    variantKey:
      typeof item.variantKey === "string" ? item.variantKey : undefined,
  };
}

/** Load cart from localStorage (defensive — never throws). */
function loadCartFromStorage(): CartItem[] {
  if (typeof window === "undefined") return [];
  try {
    const raw = window.localStorage.getItem(CART_STORAGE_KEY);
    if (!raw) return [];
    const parsed = JSON.parse(raw);
    if (!Array.isArray(parsed)) return [];
    const sanitized = parsed
      .map(sanitizeItem)
      .filter((i: CartItem | null): i is CartItem => i !== null);
    if (sanitized.length !== parsed.length) {
      console.warn(
        `[Cart] Self-healing: removed ${parsed.length - sanitized.length} corrupted item(s)`,
      );
      // Re-save sanitized version
      try {
        window.localStorage.setItem(CART_STORAGE_KEY, JSON.stringify(sanitized));
      } catch {}
    }
    return sanitized;
  } catch {
    console.warn("[Cart] Self-healing: corrupted localStorage, clearing cart");
    try {
      window.localStorage.removeItem(CART_STORAGE_KEY);
    } catch {}
    return [];
  }
}

/** Save cart to localStorage (defensive — never throws). */
function saveCartToStorage(items: CartItem[]): void {
  if (typeof window === "undefined") return;
  try {
    window.localStorage.setItem(CART_STORAGE_KEY, JSON.stringify(items));
  } catch {
    // localStorage might be full — ignore
  }
}

export function useCart() {
  const [items, setItems] = useState<CartItem[]>([]);
  const [hydrated, setHydrated] = useState(false);

  // === Load from localStorage on mount + cross-tab sync ===
  useEffect(() => {
    setItems(loadCartFromStorage());
    setHydrated(true);

    // Cross-tab synchronization — when another tab modifies the cart,
    // this tab picks up the change instantly.
    const onStorage = (e: StorageEvent) => {
      if (e.key === CART_STORAGE_KEY) {
        setItems(loadCartFromStorage());
      }
    };
    window.addEventListener("storage", onStorage);
    return () => window.removeEventListener("storage", onStorage);
  }, []);

  // === Persist helper — uses functional update to avoid stale closures ===
  const persist = useCallback((updater: CartItem[] | ((prev: CartItem[]) => CartItem[])) => {
    setItems((prev) => {
      const next = typeof updater === "function" ? updater(prev) : updater;
      saveCartToStorage(next);
      return next;
    });
  }, []);

  // === Add to cart (capped at MAX_QUANTITY, race-condition-safe) ===
  const addToCart = useCallback(
    (item: Omit<CartItem, "quantity">, quantity: number = 1) => {
      const variantKey = item.variantKey || "";
      persist((prev) => {
        const idx = prev.findIndex(
          (i) => i.productId === item.productId && (i.variantKey || "") === variantKey,
        );
        if (idx >= 0) {
          const next = [...prev];
          // Cap at MAX_QUANTITY — prevents overflow from rapid clicks
          const newQty = Math.min(
            MAX_QUANTITY,
            next[idx].quantity + quantity,
          );
          next[idx] = { ...next[idx], quantity: newQty };
          return next;
        }
        return [...prev, { ...item, quantity: Math.min(MAX_QUANTITY, Math.max(MIN_QUANTITY, quantity)) }];
      });
    },
    [persist],
  );

  // === Update quantity (race-condition-safe via functional update) ===
  const updateQuantity = useCallback(
    (productId: string, quantity: number, variantKey?: string) => {
      const vk = variantKey || "";
      if (quantity <= 0) {
        // Remove the item entirely
        persist((prev) =>
          prev.filter((i) => !(i.productId === productId && (i.variantKey || "") === vk)),
        );
        return;
      }
      const cappedQty = Math.min(MAX_QUANTITY, Math.max(MIN_QUANTITY, Math.floor(quantity)));
      let updated = false;
      persist((prev) =>
        prev.map((i) => {
          if (
            i.productId === productId &&
            (i.variantKey || "") === vk &&
            !updated
          ) {
            updated = true;
            return { ...i, quantity: cappedQty };
          }
          return i;
        }),
      );
    },
    [persist],
  );

  // === Remove item (race-condition-safe via functional update) ===
  const removeItem = useCallback(
    (productId: string, variantKey?: string) => {
      const vk = variantKey || "";
      persist((prev) =>
        prev.filter((i) => !(i.productId === productId && (i.variantKey || "") === vk)),
      );
    },
    [persist],
  );

  // === Clear cart ===
  const clearCart = useCallback(() => {
    persist([]);
  }, [persist]);

  // === Prune orphan items (called by catalog when it refreshes) ===
  // Race-condition-safe via functional update
  const pruneOrphanItems = useCallback(
    (validProductIds: Set<string>) => {
      if (validProductIds.size === 0) return; // don't prune if catalog is empty/loading
      persist((prev) => {
        const next = prev.filter((i) => validProductIds.has(i.productId));
        if (next.length < prev.length) {
          console.warn(
            `[Cart] Pruned ${prev.length - next.length} orphan item(s) — product no longer exists`,
          );
          return next;
        }
        return prev; // no change — don't trigger re-render
      });
    },
    [persist],
  );

  const count = items.reduce((sum, i) => sum + i.quantity, 0);

  return {
    items,
    hydrated,
    count,
    addToCart,
    updateQuantity,
    removeItem,
    clearCart,
    pruneOrphanItems,
  };
}
